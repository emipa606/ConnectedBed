﻿using System;
using RimWorld;

namespace zed_0xff.VNPE;

[ObsoleteAttribute]
public class Building_ConnectedBed : Building_Bed {
}
