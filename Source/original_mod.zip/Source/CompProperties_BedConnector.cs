using RimWorld;
using Verse;

namespace zed_0xff.VNPE;

public class CompProperties_BedConnector : CompProperties {
    public GraphicData graphicData;

    public CompProperties_BedConnector() {
        compClass = typeof(CompBedConnector);
    }
}

