using Verse;

namespace zed_0xff.VNPE;

public interface IPlugin {
    void ProcessPawn(Pawn pawn);
}
